<div class="wcus-layout">
    <div class="wcus-settings wcus-settings--full" style="width: 100%;">
        <div class="wcus-settings__header">
            <h1 class="wcus-settings__title"><?= __('Orders', 'wc-ukr-shipping-i18n'); ?></h1>
        </div>
        <div class="wcus-settings__content">
            <div id="wcus-order-list"></div>
        </div>
    </div>
</div>

<script>
    (function ($) {
        $(function () {
            window.WcusOrders.init({
                autoTracking: <?php echo esc_js((int)wc_ukr_shipping_get_option('wcus_sp_auto_tracking')); ?>
            });
        });
    })(jQuery);
</script>