<?php

namespace kirillbdev\WCUkrShipping\Modules\Backend;

use kirillbdev\WCUkrShipping\Component\Carriers\Ukrposhta\Label\SingleLabelDataCollector;
use kirillbdev\WCUkrShipping\Component\ListTable\AutomationListTable;
use kirillbdev\WCUkrShipping\DB\Repositories\AutomationRulesRepository;
use kirillbdev\WCUkrShipping\DB\Repositories\LegacyTtnRepository;
use kirillbdev\WCUkrShipping\DB\Repositories\ShippingLabelsRepository;
use kirillbdev\WCUkrShipping\Foundation\State;
use kirillbdev\WCUkrShipping\Helpers\WCUSHelper;
use kirillbdev\WCUkrShipping\Http\Controllers\AddressBookController;
use kirillbdev\WCUkrShipping\Http\Controllers\AutomationController;
use kirillbdev\WCUkrShipping\Http\Controllers\OptionsController;
use kirillbdev\WCUkrShipping\Http\Controllers\SmartyParcelController;
use kirillbdev\WCUkrShipping\Http\Controllers\ToolsController;
use kirillbdev\WCUkrShipping\Model\Document\TTNStore;
use kirillbdev\WCUkrShipping\Services\SmartyParcelService;
use kirillbdev\WCUkrShipping\States\OptionsPageState;
use kirillbdev\WCUkrShipping\States\OrdersState;
use kirillbdev\WCUkrShipping\States\SmartyParcelState;
use kirillbdev\WCUkrShipping\States\WarehouseLoaderState;
use kirillbdev\WCUSCore\Contracts\ModuleInterface;
use kirillbdev\WCUSCore\Foundation\View;
use kirillbdev\WCUSCore\Http\Routing\Route;

if ( ! defined('ABSPATH')) {
    exit;
}

class OptionsPage implements ModuleInterface
{
    private SmartyParcelService $smartyParcelService;
    private ShippingLabelsRepository $shippingLabelsRepository;
    private AutomationRulesRepository $automationRulesRepository;
    private LegacyTtnRepository $legacyTtnRepository;
    private AutomationListTable $table;

    public function __construct(
        SmartyParcelService $smartyParcelService,
        ShippingLabelsRepository $shippingLabelsRepository,
        AutomationRulesRepository $automationRulesRepository,
        LegacyTtnRepository $legacyTtnRepository
    ) {
        $this->smartyParcelService = $smartyParcelService;
        $this->shippingLabelsRepository = $shippingLabelsRepository;
        $this->automationRulesRepository = $automationRulesRepository;
        $this->legacyTtnRepository = $legacyTtnRepository;
    }

    public function init()
    {
        add_action('admin_menu', [$this, 'registerOptionsPage'], 99);
        add_filter('wcus_load_admin_i18n', [$this, 'registerTranslates']);
        add_action('admin_init', [$this, 'registerSettings']);
    }

    public function routes()
    {
        return [
            new Route('wcus_save_options', OptionsController::class, 'save'),
            new Route('wcus_load_areas', AddressBookController::class, 'loadAreas'),
            new Route('wcus_load_cities', AddressBookController::class, 'loadCities'),
            new Route('wcus_load_warehouses', AddressBookController::class, 'loadWarehouses'),

            new Route('wcus_smarty_parcel_check_verification', SmartyParcelController::class, 'checkVerification'),
            new Route('wcus_smarty_parcel_refresh_account', SmartyParcelController::class, 'refreshAccountInfo'),
            new Route('wcus_smarty_parcel_connect', SmartyParcelController::class, 'connect'),
            new Route('wcus_smarty_parcel_disconnect', SmartyParcelController::class, 'disconnect'),
            new Route('wcus_smarty_parcel_carrier_accounts', SmartyParcelController::class, 'getCarrierAccounts'),
            new Route('wcus_smarty_parcel_create_label', SmartyParcelController::class, 'createShippingLabel'),
            new Route('wcus_smarty_parcel_create_label_batch', SmartyParcelController::class, 'createLabelBatch'),
            new Route('wcus_smarty_parcel_void_label', SmartyParcelController::class, 'voidLabel'),
            new Route('wcus_smarty_parcel_upgrade', SmartyParcelController::class, 'upgradePlan'),
            new Route('wcus_attach_label', SmartyParcelController::class, 'attachShippingLabel'),
            new Route('wcus_automation_save_rule', AutomationController::class, 'saveRule'),

            // Tools
            new Route('wcus_tools_sync_legacy_ttn', ToolsController::class, 'syncLegacyTtn'),
        ];
    }

    public function registerOptionsPage()
    {
        State::add('warehouse_loader', WarehouseLoaderState::class);
        State::add('options', OptionsPageState::class);
        State::add('smarty_parcel', SmartyParcelState::class);
        State::add('orders', OrdersState::class);

        add_menu_page(
            __('Settings', 'wc-ukr-shipping-i18n'),
            'WC Ukr Shipping',
            'manage_options',
            'wc_ukr_shipping_options',
            [$this, 'html'],
            WC_UKR_SHIPPING_PLUGIN_URL . 'image/menu-icon.png',
            56.15
        );

        add_submenu_page(
            'wc_ukr_shipping_options',
            __('Smarty Parcel', 'wc-ukr-shipping-i18n'),
            __('Smarty Parcel', 'wc-ukr-shipping-i18n'),
            'manage_options',
            'wcus_smarty_parcel',
            [$this, 'smartyParcelHtml']
        );

        add_submenu_page(
            '',
            __('Create TTN', 'wc-ukr-shipping-i18n'),
            __('Create TTN', 'wc-ukr-shipping-i18n'),
            'manage_woocommerce',
            'wc_ukr_shipping_ttn',
            [$this, 'ttnHtml']
        );

        add_submenu_page(
            'wc_ukr_shipping_options',
            __('Orders', 'wc-ukr-shipping-i18n'),
            __('Orders', 'wc-ukr-shipping-i18n'),
            'manage_woocommerce',
            'wc_ukr_shipping_ttn_list',
            [$this, 'orderListHtml']
        );

        $automationPage = add_submenu_page(
            'wc_ukr_shipping_options',
            __('Automation', 'wc-ukr-shipping-i18n'),
            __('Automation', 'wc-ukr-shipping-i18n'),
            'manage_woocommerce',
            'wcus_automation',
            [$this, 'automationHtml']
        );
        add_action("load-$automationPage", function () {
            $this->table = new AutomationListTable($this->automationRulesRepository);
        });

        add_submenu_page(
            '',
            __('Create', 'wc-ukr-shipping-i18n'),
            __('Create', 'wc-ukr-shipping-i18n'),
            'manage_woocommerce',
            'wcus_automation_rule_create',
            [$this, 'automationRuleFormHtml']
        );

        add_submenu_page(
            '',
            __('Edit', 'wc-ukr-shipping-i18n'),
            __('Edit', 'wc-ukr-shipping-i18n'),
            'manage_woocommerce',
            'wcus_automation_rule_edit',
            [$this, 'automationRuleFormHtml']
        );

        add_submenu_page(
            'wc_ukr_shipping_options',
            __('Tools', 'wc-ukr-shipping-i18n'),
            __('Tools', 'wc-ukr-shipping-i18n'),
            'manage_options',
            'wc_ukr_shipping_tools',
            [$this, 'toolsHtml']
        );

        add_submenu_page(
            '',
            __('Upgrade pricing plan', 'wc-ukr-shipping-i18n'),
            __('Upgrade pricing plan', 'wc-ukr-shipping-i18n'),
            'manage_woocommerce',
            'wcus_smarty_parcel_upgrade_plan',
            [$this, 'upgradePlanHtml']
        );
    }

    public function registerSettings(): void
    {
        register_setting('wcus_settings_tools', 'wcus_legacy_pro_tracking', 'intval');
    }

    public function registerTranslates($i18n): array
    {
        return array_merge($i18n, [
            'warehouse_loader' => [
                'title' => __('Warehouses data of Nova Poshta', 'wc-ukr-shipping-i18n'),
                'last_update' => __('Last update date:', 'wc-ukr-shipping-i18n'),
                'status' => __('Status:', 'wc-ukr-shipping-i18n'),
                'status_not_completed' => __('Not completed', 'wc-ukr-shipping-i18n'),
                'status_completed' => __('Completed', 'wc-ukr-shipping-i18n'),
                'status_unknown' => __('Unknown', 'wc-ukr-shipping-i18n'),
                'update' => __('Update warehouses', 'wc-ukr-shipping-i18n'),
                'continue' => __('Continue update', 'wc-ukr-shipping-i18n'),
                'load_areas' => __('Load areas...', 'wc-ukr-shipping-i18n'),
                'load_cities' => __('Load cities...', 'wc-ukr-shipping-i18n'),
                'load_warehouses' => __('Load warehouses...', 'wc-ukr-shipping-i18n'),
                'success_updated' => __('Warehouses db updated successfully', 'wc-ukr-shipping-i18n'),
            ],
            'smarty_parcel' => [],
            'text_confirm_re_run_migrations' => __('Are you sure to restart migrations? This action cannot be canceled.', 'wc-ukr-shipping-i18n'),
        ]);
    }

    public function html()
    {
        $data = [];
        $gateways = wcus_is_woocommerce_active() ? wc()->payment_gateways()->payment_gateways() : [];
        $paymentMethods = [];
        foreach ($gateways as $id => $gateway) {
            $paymentMethods[$id] = $gateway->get_title();
        }
        $data['payment_methods'] = $paymentMethods;
        $data['cod_payment_id'] = wc_ukr_shipping_get_option('wcus_cod_payment_id');
        $data['payment_control_default'] = (int)wc_ukr_shipping_get_option('wcus_ttn_pay_control_default');
        $data['carrierAccounts'] = $this->smartyParcelService->getCarrierAccounts();

        $section = $_GET['section'] ?? null;
        switch ($section) {
            case 'nova_poshta':
                $view = 'settings_nova_poshta';
                break;
            case 'ukrposhta':
                $view = 'settings_ukrposhta';
                break;
            case 'nova_post':
                $view = 'settings_nova_post';
                break;
            case 'rozetka':
                $view = 'settings_rozetka';
                break;
            default:
                $view = 'settings_general';
        }

        echo View::render($view, $data);
    }

    public function smartyParcelHtml()
    {
        echo View::render('smarty_parcel');
    }

    public function ttnHtml(): void
    {
        if (get_option(WCUS_OPTION_SMARTY_PARCEL_USER_STATUS) !== 'connected') {
            echo View::render('ttn/ttn_forbidden');
            return;
        }

        $label = $this->shippingLabelsRepository->findByOrderId((int)$_GET['order_id']);
        if ($label !== null) {
            return;
        }

        wp_enqueue_script(
            'wcus_ttn_form_js',
            WC_UKR_SHIPPING_PLUGIN_URL . 'assets/js/ttn-form.min.js',
            [ 'jquery' ],
            filemtime(WC_UKR_SHIPPING_PLUGIN_DIR . 'assets/js/ttn-form.min.js'),
            true
        );

        $order = wc_get_order((int)$_GET['order_id']);
        if ( ! $order) {
            throw new \InvalidArgumentException('Order #' . (int)$_GET['order_id'] . ' not found.');
        }

        $carrier = null;
        if (isset($_GET['carrier'])) {
            $carrier = $_GET['carrier'];
        } elseif ($order->has_shipping_method(WC_UKR_SHIPPING_NP_SHIPPING_NAME)) {
            $carrier = 'nova_poshta';
        } elseif ($order->has_shipping_method('wcus_ukrposhta_shipping')) {
            $carrier = 'ukrposhta';
        }

        $store = null;
        switch ($carrier) {
            case 'nova_poshta':
                $store = new TTNStore((int)$_GET['order_id']);
                break;
            case 'ukrposhta':
                $store = new SingleLabelDataCollector($order);
                break;
        }

        if ($store === null) {
            $shippingMethod = WCUSHelper::getOrderShippingMethod($order);
            echo View::render('ttn/ttn_custom', [
                'shippingMethod' => $shippingMethod !== null ? $shippingMethod->get_name() : null,
                'novaPoshtaFormUrl' => admin_url(
                    'admin.php?page=wc_ukr_shipping_ttn&order_id=' . $order->get_id() . '&carrier=nova_poshta'
                ),
                'ukrposhtaFormUrl' => admin_url(
                    'admin.php?page=wc_ukr_shipping_ttn&order_id=' . $order->get_id() . '&carrier=ukrposhta'
                ),
            ]);
        } else {
            wp_localize_script('wcus_ttn_form_js', 'wcus_ttn_form_state', $store->collect());
            echo View::render('ttn/ttn');
        }
    }

    public function orderListHtml(): void
    {
        echo View::render('orders');
    }

    public function automationHtml()
    {
        if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
            if (wp_verify_nonce($_GET['_wpnonce'] ?? '', 'wcus_automation_delete')) {
                $this->automationRulesRepository->delete((int)$_GET['id']);
            }
        }

        $this->table->prepare_items();
        ?>
        <div class="wrap">
            <h1 class="wp-heading-inline"><?php echo esc_html(get_admin_page_title()); ?></h1>
            <a href="<?php echo esc_attr(admin_url('admin.php?page=wcus_automation_rule_create')); ?>"
               class="page-title-action"><?php esc_html_e('Add rule', 'wc-ukr-shipping-i18n'); ?></a>
            <hr class="wp-header-end">
            <form action="" method="POST">
                <?php $this->table->display(); ?>
            </form>
        </div>
        <?php
    }

    public function automationRuleFormHtml(): void
    {
        $id = (int)($_GET['id'] ?? 0);
        $model = null;
        if ($id > 0) {
            $model = $this->automationRulesRepository->findById($id);
            if ($model === null) {
                echo sprintf(
                    '<div class="notice notice-error">%s</div>',
                    __('Rule not found', 'wc-ukr-shipping-pro')
                );
                return;
            }
        }

        echo View::render('automation', [
            'model' => $model,
            'successMsg' => isset($_GET['success']) && $_GET['success'] === '1'
                ? __('Rule saved successfully', 'wc-ukr-shipping-pro')
                : null,
        ]);
    }

    public function toolsHtml(): void
    {
        echo View::render('tools', [
            'legacyTtnCount' => $this->legacyTtnRepository->getCountTtn(),
        ]);
    }

    public function upgradePlanHtml(): void
    {
        echo View::render('upgrade_plan', [
            'quotaReached' => isset($_GET['source']) && $_GET['source'] === 'free_quota_reached',
        ]);
    }
}
