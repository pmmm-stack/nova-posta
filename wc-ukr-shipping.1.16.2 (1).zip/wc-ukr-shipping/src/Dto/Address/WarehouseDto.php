<?php

namespace kirillbdev\WCUkrShipping\Dto\Address;

if ( ! defined('ABSPATH')) {
    exit;
}

class WarehouseDto
{
    public $ref;
    public $name;
}