<?php

namespace kirillbdev\WCUkrShipping\Dto\Address;

if ( ! defined('ABSPATH')) {
    exit;
}

class CityDto
{
    public $ref;
    public $name;
}