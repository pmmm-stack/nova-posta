<?php

declare(strict_types=1);

namespace kirillbdev\WCUkrShipping\Address\Exception\Provider;

class UnauthorizedException extends \Exception
{

}
