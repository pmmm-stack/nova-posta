<?php

declare(strict_types=1);

namespace kirillbdev\WCUkrShipping\Address\Exception\Provider;

class LicenseNotFoundException extends \Exception
{

}
