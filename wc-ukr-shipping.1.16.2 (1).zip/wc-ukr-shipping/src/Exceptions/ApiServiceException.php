<?php

namespace kirillbdev\WCUkrShipping\Exceptions;

if ( ! defined('ABSPATH')) {
  exit;
}

class ApiServiceException extends \Exception
{

}