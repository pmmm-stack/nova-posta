<?php

namespace kirillbdev\WCUkrShipping\Exceptions;

if ( ! defined('ABSPATH')) {
    exit;
}

class NovaPoshtaAddressProviderException extends \Exception
{

}